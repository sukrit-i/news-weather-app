import { useState } from "react"
import { NewsBoard } from "./Components/NewsBoard"
import { Navbar } from "./Components/Navbar"

export const App = () => {
  const[ category , setCategory] = useState("general");
  return (
    <div>
      <Navbar setCategory={setCategory} />
      <NewsBoard category={category} /> 
    </div>
  )
}
