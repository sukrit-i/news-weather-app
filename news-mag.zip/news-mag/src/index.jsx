import { App } from "./App"; // If App.jsx is in the same directory as index.jsx
