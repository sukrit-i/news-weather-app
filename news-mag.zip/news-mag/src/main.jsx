import React from "react";
import ReactDOM from "react-dom/client";
import { App } from "./App"; // Importing the App component
 // Assuming you have a global CSS file

// Create a root element to render the App
const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
